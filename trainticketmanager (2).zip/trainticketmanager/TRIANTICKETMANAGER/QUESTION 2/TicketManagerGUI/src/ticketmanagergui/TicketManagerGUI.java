/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ticketmanagergui;

/**
 *
 * @author masek
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TicketManagerGUI extends JFrame {

    // Inner class for TrainTicket 
    static class TrainTicket {
        private String passengerName;
        private String destination;
        private String ticketClass;
        private double basePrice;
        private double finalPrice;

        public TrainTicket(String passengerName, String destination, String ticketClass, double basePrice) {
            if (passengerName == null || passengerName.trim().isEmpty()) {
                throw new IllegalArgumentException("Passenger name cannot be empty.");
            }
            this.passengerName = passengerName.trim();

            this.destination = destination; // validated via combo box

            this.ticketClass = ticketClass; // validated via combo box

            this.basePrice = basePrice;
            this.finalPrice = ticketClass.equalsIgnoreCase("Business") ? basePrice * 1.5 : basePrice;
        }

        public String getTicketDetails() {
            return String.format(
                    "--- Ticket Details ---\nName: %s\nDestination: %s\nClass: %s\nBase Price: R%.2f\nFinal Price: R%.2f\n\n",
                    passengerName, destination, ticketClass, basePrice, finalPrice);
        }
    }

    private ArrayList<TrainTicket> tickets;

    // Swing components
    private JTextField nameField;
    private JComboBox<String> destinationBox;
    private JComboBox<String> classBox;
    private JButton addButton;
    private JTextArea displayArea;

    // Options for drop-downs
    private String[] destinations = {
        "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo",
        "Mpumalanga", "Northern Cape", "North West", "Western Cape"
    };
    private String[] ticketClasses = {"Economy", "Business"};

    public TicketManagerGUI() {
        super("Train Ticket Reservation System");
        tickets = new ArrayList<>();

        // Create components 
        JLabel nameLabel = new JLabel("Passenger Name:");
        nameField = new JTextField(15);

        JLabel destinationLabel = new JLabel("Destination (Province):");
        destinationBox = new JComboBox<>(destinations);

        JLabel classLabel = new JLabel("Ticket Class:");
        classBox = new JComboBox<>(ticketClasses);

        addButton = new JButton("Add Ticket");
        displayArea = new JTextArea(15, 50);
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(displayArea);

        //  Layout setup 
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2, 5, 5));
        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(destinationLabel);
        inputPanel.add(destinationBox);
        inputPanel.add(classLabel);
        inputPanel.add(classBox);
        inputPanel.add(new JLabel()); // empty cell
        inputPanel.add(addButton);

        this.setLayout(new BorderLayout());
        this.add(inputPanel, BorderLayout.NORTH);
        this.add(scrollPane, BorderLayout.CENTER);

        // --- Button listener ---
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addTicket();
            }
        });

        // Window settings
        this.pack();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null); // center
        this.setVisible(true);
    }

    private void addTicket() {
        String name = nameField.getText().trim();
        String destination = (String) destinationBox.getSelectedItem();
        String ticketClass = (String) classBox.getSelectedItem();

        try {
            TrainTicket ticket = new TrainTicket(name, destination, ticketClass, 2000);
            tickets.add(ticket);
            displayTickets();

            // Clear name field for next entry
            nameField.setText("");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void displayTickets() {
        StringBuilder sb = new StringBuilder();
        for (TrainTicket t : tickets) {
            sb.append(t.getTicketDetails());
        }
        displayArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TicketManagerGUI());
    }
}